<?php

require_once('Config/db.php');
$query = "select * from company";
$result = mysqli_query($con, $query);


?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <title>Responsive Job Portal Website</title>
</head>

<body>
    <!-- sidebar-->
    <div class="sidebar">
        <h1 class="logo text-align:center">SES ADMIN PAGE</h1>
    </div>

    </div>

    <!--  main -->
    <div class="main">

        <div class="filter-wrapper">
            <h2>Recommendation</h2>
            <div class="filter">
                <button onclick="location.href='addCompany.php'" class="btn-filterc">Create
                    New Job</button>
                <button class="btn-filters">Read Job Detail</button>
            </div>
            <div class="wrapper">
                <div class="card-center">
                    <table class="table table-bordered text-center">
                        <tr>
                            <th>Company Name</th>
                            <th>Company Address</th>
                            <th>Company Email</th>
                            <th>Company Phone Number</th>
                            <th>Job Vacancy</th>
                            <th>Update</th>
                            <th>Delete</th>
                        </tr>
                        <tr>
                            <?php

                            while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                                <td><?php echo $row['COMPANY_NAME']; ?></td>
                                <td><?php echo $row['COMPANY_ADDRESS']; ?></td>
                                <td><?php echo $row['COMPANY_EMAIL']; ?></td>
                                <td><?php echo $row['COMPANY_PHONE']; ?></td>
                                <td><?php echo $row['JOB_POSITION']; ?></td>
                                <td><a href='#' class="btn-filter">Update</td>
                                <td><a href='#' class="btn-filters">Delete</td>
                        </tr>
                    <?php
                            }

                    ?>

                    </table>
                </div>
            </div>








        </div>
    </div>

    <!-- right section: detail jobs-->
    <div class="detail">
        <ion-icon class="close-detail" name="close-outline"></ion-icon>
        <div class="detail-header">
            <img src="images/google.svg">
            <h2>Google</h2>
            <p>Data Science</p>
        </div>
        <hr class="divider">
        <div class="detail-desc">
            <div class="about">
                <h4>About Company</h4>
                <p>American multinational technology company focusing on artificial intelligence,online advertising,
                    search engine technology, cloud computing,computer software, quantum computing, e-commerce, and
                    consumer electronics.</p>
                <a href="https://en.wikipedia.org/wiki/Google">Read
                    More</a>
            </div>
            <hr class="divider">
            <div class="qualification">
                <h4>Qualification</h4>
                <ul>
                    <li>Master's degree in Statistics, Mathematics, Data Science,
                        Engineering, Physics, Economics,or a related quantitative field.</li>
                    <li>5 years of work experience with analysis applications (extracting insights, performing
                        statistical analysis, or solving business problems),
                        and coding (Python, R, SQL).</li>
                </ul>
            </div>
        </div>
        <hr class="divider">
    </div>



</body>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="app.js"></script>

</html>