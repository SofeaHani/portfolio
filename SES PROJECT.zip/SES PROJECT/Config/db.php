<?php

$con = mysqli_connect("localhost", "root", "", "ses_database");

if (!$con) {
    die("Connection Error");
}
