<?php
include('dbconn.php');
if(isset($_POST['add'])) {
    $cname = $_POST['cname'];
    $caddress = $_POST['caddress'];
    $email = $_POST['email'];
    $cnumber = $_POST['cnumber'];
    $position = $_POST['position'];
  

    $sql = "INSERT INTO COMPANY (COMPANY_NAME, COMPANY_ADDRESS, COMPANY_EMAIL, COMPANY_PHONE, JOB_POSITION) VALUES ('$cname', '$caddress', '$email', '$cnumber', '$position')";
    $result = mysqli_query($dbconn, $sql);

    if ($result) {
        header('location:listCompany.php');
    } else {
        // Handle error in query execution
        echo "Error inserting data: " . mysqli_error($dbconn);
    }
}
?>

<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <title> SES Project </title>
    <link rel="stylesheet" href="style.css">

    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

    <!--  navigation bar section  -->

    <div class="sidebar close">

        <!-- ========== Logo ============  -->

        <div class="logo-details">
            <i class='bx bx-user-circle'></i>
            <span class="logo_name">Welcome Admin</span>
        </div>

        <!-- ========== List ============  -->

        <ul class="nav-links">

            <!-- -------- Non Dropdown List Item ------- -->
            <li>
                <a href="adminDashoard.php">
                    <i class='bx bx-grid-alt'></i>
                    <span class="link_name">Dashboard</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a href="#" class="link_name" href="adminDashoard.php">Dashboard</a></li>
                </ul>
            </li>

            <!-- -------- Non Dropdown List Item ------- -->
            <li>
                <a href="listCompany.php">
                    <i class='bx bx-grid-alt'></i>
                    <span class="link_name">List Companies</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a href="#" class="link_name" href="listCompany.php">List Companies</a></li>
                </ul>
            </li>

            <!-- -------- Non Dropdown List Item ------- -->
            <li>
                <a href="addCompany.php">
                    <i class='bx bx-clinic'></i>
                    <span class="link_name">Add Company</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a class="link_name" href="addCompany.php">Add Company</a></li>
                </ul>
            </li>

            <!-- -------- Non Dropdown List Item ------- -->
            <li>
                <a onclick="return confirm('Are you sure you want to log out?');" href="adminLogout.php">
                    <i class='bx bx-log-out'></i>
                    <span class="link_name">Log Out</span>
                </a>
                <ul class="sub-menu blank">
                    <li><a onclick="return confirm('Are you sure you want to log out?');" href="adminLogout.php"
                            class="link_name" href="#">Log Out</a></li>
                </ul>
            </li>
        </ul>
    </div>

    <style>
        /* Google Fonts Import Link */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            overflow: hidden;
        }

        /* =============== Sidebar =============== */

        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 260px;
            background: #11101d;
            z-index: 100;
            transition: all 0.5s ease;
        }

        .sidebar.close {
            width: 78px;
        }

        /* --------- Logo ------------ */

        .sidebar .logo-details {
            height: 60px;
            width: 100%;
            display: flex;
            align-items: center;
        }

        .sidebar .logo-details i {
            font-size: 30px;
            color: #fff;
            height: 50px;
            min-width: 78px;
            text-align: center;
            line-height: 50px;
        }

        .sidebar .logo-details .logo_name {
            font-size: 18px;
            color: #fff;
            font-weight: 600;
            transition: 0.3s ease;
            transition-delay: 0.1s;
        }

        .sidebar.close .logo-details .logo_name {
            transition-delay: 0s;
            opacity: 0;
            pointer-events: none;
        }

        /* ---------- Sidebar List ---------- */

        .sidebar .nav-links {
            height: 100%;
            padding: 30px 0 150px 0;
            overflow: auto;
        }

        .sidebar.close .nav-links {
            overflow: visible;
        }

        .sidebar .nav-links::-webkit-scrollbar {
            display: none;
        }

        .sidebar .nav-links li {
            position: relative;
            list-style: none;
            transition: all 0.4s ease;
            padding-bottom: 20px;
        }

        .sidebar .nav-links li:hover {
            background: #1d1b31;
        }

        .sidebar .nav-links li .iocn-link {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .sidebar.close .nav-links li .iocn-link {
            display: block
        }

        .sidebar .nav-links li i {
            height: 50px;
            min-width: 78px;
            text-align: center;
            line-height: 50px;
            color: #fff;
            font-size: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .sidebar .nav-links li.showMenu i.arrow {
            transform: rotate(-180deg);
        }

        .sidebar.close .nav-links i.arrow {
            display: none;
        }

        .sidebar .nav-links li a {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .sidebar .nav-links li a .link_name {
            font-size: 18px;
            font-weight: 400;
            color: #fff;
            transition: all 0.4s ease;
        }

        .sidebar.close .nav-links li a .link_name {
            opacity: 0;
            pointer-events: none;
        }

        /* ---------------- Submenu ------------- */

        .sidebar .nav-links li .sub-menu {
            padding: 6px 6px 14px 80px;
            margin-top: -10px;
            background: #1d1b31;
            display: none;
        }

        .sidebar .nav-links li.showMenu .sub-menu {
            display: block;
        }

        .sidebar .nav-links li .sub-menu a {
            color: #fff;
            font-size: 15px;
            padding: 5px 0;
            white-space: nowrap;
            opacity: 0.6;
            transition: all 0.3s ease;
        }

        .sidebar .nav-links li .sub-menu a:hover {
            opacity: 1;
        }

        .sidebar.close .nav-links li .sub-menu {
            position: absolute;
            left: 100%;
            top: -10px;
            margin-top: 0;
            padding: 10px 20px;
            border-radius: 0 6px 6px 0;
            opacity: 0;
            display: block;
            pointer-events: none;
            transition: 0s;
        }

        .sidebar.close .nav-links li:hover .sub-menu {
            top: 0;
            opacity: 1;
            pointer-events: auto;
            transition: all 0.4s ease;
        }

        .sidebar .nav-links li .sub-menu .link_name {
            display: none;
        }

        .sidebar.close .nav-links li .sub-menu .link_name {
            font-size: 18px;
            opacity: 1;
            display: block;
        }

        .sidebar .nav-links li .sub-menu.blank {
            opacity: 1;
            pointer-events: auto;
            padding: 3px 20px 6px 16px;
            opacity: 0;
            pointer-events: none;
        }

        .sidebar .nav-links li:hover .sub-menu.blank {
            top: 50%;
            transform: translateY(-50%);
        }

        /* ---------------- Submenu Close ------------- */

        .sidebar.close .profile-details i,
        .sidebar.close .profile-details .profile_name,
        .sidebar.close .profile-details .job {
            display: none;
        }

        .sidebar .profile-details .job {
            font-size: 12px;
        }

        /* ============ Responsive / Breakpoints ========== */

        @media screen and (max-width: 400px) {
            .sidebar {
                width: 240px;
            }

            .sidebar.close {
                width: 78px;
            }

            .sidebar .profile-details {
                width: 240px;
            }

            .sidebar.close .profile-details {
                background: none;
            }

            .sidebar.close .profile-details {
                width: 78px;
            }

            .home-section {
                left: 240px;
                width: calc(100% - 240px);
            }

            .sidebar.close~.home-section {
                left: 78px;
                width: calc(100% - 78px);
            }
        }

        @media (max-width: 1080px) {}

        /* For Medium Devices */
        @media (max-width: 774px) {}

        @media (max-width: 560px) {}

        /* For Small Devices */
        @media (max-width: 360px) {}
    </style>

    <!--  navigation bar section end  -->

    <!-- ============= Home Section =============== -->

    <section class="home-section">
        <div class="home-content">
            <i class='bx bx-menu'></i>
            <span class="text">COMPANY LIST</span>
        </div> <br> <br>

        <div class="container-fluid">
            <div class="col-lg-12"> 
                <div class="row">
                    <!-- Table Panel -->
                        <div class="col-lg-15">
                            <div class="card">
                                <div class="card-header">
                                    <div class="row1">
                                        <div class="col-lg-12">
                                            <span><large><b>Staff List</b></large></span>
                                            <a class="btn btn-primary" href="adminAddStaff.php" role="button">New Staff</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <br>
                                    <table class="table table-bordered table-hover">
                                        <colgroup>
                                            <col width="10%">
                                            <col width="30%">
                                            <col width="30%">
                                            <col width="30%">
                                        </colgroup>
                                        <thead>
                                            <tr>
                                                <th class="text-center">#</th>
                                                <th class="text-center">Staff Name</th>
                                                <th class="text-center">Staff Job</th>
                                                <th class="text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php
                                            $i = 1;
                                            $sql = "SELECT STAFF_ID, STAFF_NAME, STAFF_JOB FROM STAFF";

                                            $result=mysqli_query($dbconn,$sql);
                                            if($result) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    $id=$row['STAFF_ID'];
                                                    $name=$row['STAFF_NAME'];
                                                    $job=$row['STAFF_JOB'];
                                            
                                                    echo 
                                                    '<tr>
                                                        <td class="text-center">'.$i++.'</td>
                                                        <td class="text-center">'.$name.'</td>
                                                        <td class="text-center">'.$job.'</td>
                                                        <td class="text-center">
                                                            <a href="adminViewStaff.php?viewcode='.$id.'" class="btn btn-sm btn-primary">View</a>';
                                                            ?>
                                                            <a href="adminEditStaff.php?editcode=<?php echo $row['STAFF_ID'] ?>" class="btn btn-sm btn-warning">Edit</a>
                                                            <a onclick="return confirm('Are you sure you want to delete this record?');" href="adminDeleteStaff.php?deletecode=<?php echo $row['STAFF_ID'] ?>" class="btn btn-sm btn-danger">Delete</a>
                                                        </td>
                                                    </tr>
                                                <?php
                                                }
                                                
                                                if(mysqli_num_rows($result)==0) {
                                                    echo "No Data Found";
                                                }
                                            }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>        
                            </div>

                            <!-- Table Panel -->
                            <div class="index-btn-wrapper">
                                <button class="index-btn" style="background: #1f78bb;"><a href="adminDetailDoctor.php">Doctor Details</a></button>
                                <button class="index-btn" style="background: #1f78bb;"><a href="adminDetailNurse.php">Nurse Details</a></button>
                            </div>
                        </div>                    
                    </div>
                </div>


            <style>
                body {
                    overflow: auto;
                    background: #E4E9F7;
                }

                .home-section {
                    position: relative;
                    background: #E4E9F7;
                    left: 260px;
                    width: calc(100% - 260px);
                    transition: all 0.5s ease;
                    padding: 12px;

                }

                .sidebar.close~.home-section {
                    left: 78px;
                    width: calc(100% - 78px);
                }

                .home-content {
                    display: flex;
                    align-items: center;
                    flex-wrap: wrap;
                }

                .home-section .home-content .bx-menu,
                .home-section .home-content .text {
                    color: #11101d;
                    font-size: 35px;
                }

                .home-section .home-content .bx-menu {
                    cursor: pointer;
                    margin-right: 10px;
                }

                .home-section .home-content .text {
                    font-size: 26px;
                    font-weight: 600;
                }


                .bodyInfo {
                    display: flex;
                    justify-content: center;
                    padding-left: 80px;
                }

                .info {
                    margin-bottom: 10px;
                    max-width: 900px;
                    width: 100%;
                    background: rgb(255, 255, 255);
                    padding: 25px 35px;
                    border-radius: 5px;
                    box-shadow: 0px 5px 10px 0px rgb(116, 114, 114);
                }

                .info .title {
                    font-size: 25px;
                    font-weight: 500;
                    position: relative;
                }

                .info .title::before {
                    content: '';
                    position: absolute;
                    left: 0;
                    bottom: 0;
                    height: 3px;
                    width: 30px;
                    background: linear-gradient(170deg, #000000, #575fcc);
                }

                .index-btn-wrapper {
                    text-align: center;
                }

                a {
                    text-decoration: none;
                    color: #fff;
                }

                .col-md-12 .btn {
                    margin: 20px 10px 0 0;
                    text-align: center;
                    line-height: 30px;
                    border-radius: 12px;
                    background: #2E94E3;
                    color: #fff;
                    border: none;
                    width: 100%;
                    height: 40px;
                    font-size: 15px;
                    font-weight: 600;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                    border-radius: 5px;
                    cursor: pointer;
                    transition: 0.3s;
                }

                .row1 .col-lg-12 .btn {
                    float: right;
                }

                .index-btn:hover{
                    opacity: 0.8;
                    background: #2E94E3;
                }

                
                td{
                    vertical-align: middle !important;
                }
                td p{
                    margin: unset
                }
                img{
                    max-width:100px;
                    max-height: :150px;
                }

                .index-btn-wrapper {
                    float: center;
                }

                .index-btn {
                    margin: 20px 10px 0 0;
                    text-align: center;
                    line-height: 40px;
                    border-radius: 12px;
                    background: #2E94E3;
                    color: #fff;
                    border: none;
                    width: 200px;
                    height: 40px;
                    font-size: 15px;
                    font-weight: 600;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                    border-radius: 5px;
                    cursor: pointer;
                    transition: 0.3s;
                }

                @media (max-width:1000px) {

                    .bodyInfo {
                        padding-right: 1cm;
                    }

                }

                ::-webkit-scrollbar {
                    width: 10px;
                }

                ::-webkit-scrollbar-track {
                    border-radius: 5px;
                    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.25);
                }

                ::-webkit-scrollbar-thumb {
                    border-radius: 5px;
                    background-color: #5a5b5c;
                }

                ::-webkit-scrollbar-thumb:hover {
                    background-color: #282929;
                }
            </style>

        </section>

    <script>
        let arrow = document.querySelectorAll(".arrow");
        for (var i = 0; i < arrow.length; i++) {
            arrow[i].addEventListener("click", (e) => {
                let arrowParent = e.target.parentElement.parentElement;//selecting main parent of arrow
                arrowParent.classList.toggle("showMenu");
            });
        }

        let sidebar = document.querySelector(".sidebar");
        let sidebarBtn = document.querySelector(".bx-menu");
        console.log(sidebarBtn);
        sidebarBtn.addEventListener("click", () => {
            sidebar.classList.toggle("close");
        });
    </script>
</body>

</html>