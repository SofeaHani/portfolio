package com.example.sofeahaniapp;


import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;


import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    ActionBar actionBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#F13172")));


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Option Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if(id == R.id.menu_home){
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,MainActivity.class));
        }
        else if (id == R.id.menu_aboutme){
            Toast.makeText(this, "About Me", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,AboutMe.class));
        }
        else if (id == R.id.menu_hobbies){
            Toast.makeText(this, "Hobbies", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,Hobbies.class));
        }
        else if (id == R.id.menu_skills){
            Toast.makeText(this, "Skills", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,Skills.class));
        }
        else if (id == R.id.menu_timetable){
            Toast.makeText(this, "Timetable", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,Timetable.class));
        }
        else if (id == R.id.menu_uitmwebsite){
            Toast.makeText(this, "Uitm Website", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,UitmWebsite.class));
        }
        else if (id == R.id.menu_istudent){
            Toast.makeText(this, "IStudent Portal", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this,IStudentPortal.class));
        }

        return super.onOptionsItemSelected(item);
    }
}