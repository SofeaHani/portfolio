package com.example.sofeahaniapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Skills extends MainActivity {

    Button btnJava,btnC,btnHTML;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_skills);

        // Java button
        btnJava = findViewById(R.id.btn_java);

        btnJava.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Skills.this, "Java is a high-level, class-based," +
                        " object-oriented programming language that is designed to have as few implementation dependencies as possible. ",
                        Toast.LENGTH_SHORT).show();
            }

        });

        // C++ button
        btnC = findViewById(R.id.btn_c);

        btnC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Skills.this, "C++ is one of the most widely used programming languages.C++ can be found in modern operating systems, " +
                                "graphical user interfaces, and embedded technologies.\n" + "C++ is an object-oriented programming language that provides a clear" +
                                " structure to programs and enables for code reuse, saving development costs.\n" +
                                "\n" +
                                "\n" +
                                "\n ",
                        Toast.LENGTH_SHORT).show();
            }

        });

        // HTML button
        btnHTML = findViewById(R.id.btn_html);

        btnHTML.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Skills.this, "HyperText Markup Language (HTML) is the standard markup language for documents designed to be displayed in a web browser. " +
                        "It defines the content and structure of web content" , Toast.LENGTH_SHORT).show();
            }

        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

}

